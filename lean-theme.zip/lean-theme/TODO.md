# Lean Theme TODO

## Enhancements

### Add testimonial categories to the theme (native)
**Status:** proven as a per-site snippet; fold into the theme so every lean-theme site gets it.

The `testimonials` CPT (`inc/cpts.php`) currently has **no taxonomy**, and the `[testimonials]` shortcode (`inc/shortcodes/testimonials.php`) cannot filter by category. On The Roc Foundation Repair we needed category-filtered testimonial feeds per service page, so we built this as a site snippet:

- **Reference implementation:** `/Users/nomis/Desktop/codeprojects/roc-foundation-repair/wp-snippets/testimonial-category.php`
  - Registers a `testimonial_category` taxonomy on the `testimonials` CPT
  - Seeds category terms (6 on Roc: foundation-repair, general-trust, concrete-flatwork, roofing-gutters, drainage, plumbing — make the seed list theme-configurable, not hardcoded)
  - Overrides `[testimonials]` to accept a `category="slug"` attribute (tax_query)

**Scope boundary — theme = mechanism, not categorization.** The theme should provide ONLY: the taxonomy + a category-filterable shortcode + REST-assignable terms. It does NOT auto-categorize reviews. On Roc the per-review category assignment was a **data/import-time step**: reviews were downloaded, an **LLM categorized each one** (incl. multi-category cases), then they were imported with the right terms applied. That pipeline lives in the SITE project, not the theme:
- `roc-foundation-repair/scripts/import_testimonials.py` — imports reviews + applies category terms
- `roc-foundation-repair/scripts/retag_multicategory.py` — LLM multi-category retag (fixed keyword false positives)
- Source data: `roc-foundation-repair/data/reviews.md`

**To make it native:**
1. Register `testimonial_category` in `inc/cpts.php` alongside the CPT, with `show_in_rest => true` (so categories are assignable in the editor and settable via REST — the import/LLM step writes to it through REST).
2. Update `inc/shortcodes/testimonials.php` to accept a `category` attr and add the `tax_query` when present (keep backward-compatible: no `category` = current behavior / all testimonials).
3. Do NOT hardcode category terms in the theme — let each site seed its own (admin UI or a filter), since term sets are site-specific.
4. Keep the download → LLM-categorize → import pipeline as a per-site concern; the theme just exposes the taxonomy it writes into.
5. **Add a `layout` attribute to `[testimonials]`** so one dataset can render different looks across sites: `layout="grid"` (default, `.items-grid`/`.items-card`) and `layout="cards"` (Bootstrap `.row` of `.review-card` with `.stars`/`.quote`/`.reviewer`/`.city`, the landing-page look in `lean-pages.css`). Both must emit identical schema.org/Review markup. Proven in `roc-foundation-repair/wp-snippets/testimonial-category.php`.
6. After merging, retire the per-site snippet on sites that adopt the new theme version.

_Noted 2026-06-19 during the Roc build._

## Performance / Perfmatters

### Perfmatters settings are seeded by the theme (out-of-the-box PSI ~100)
- `inc/perfmatters-defaults.php` auto-imports `assets/perfmatters/perfmatters-config.json`
  ONCE on theme activation (hook `after_switch_theme`), if the Perfmatters plugin is active.
- Seeds: Remove Unused CSS = ON / Used CSS Method = **Inline**, Defer JS = ON, Delay JS = ON
  (Only Delay Specified: `bootstrap.bundle`). Minify left to Breeze.
- Guarded: runs once per site (option `lean_perfmatters_defaults_imported`), never clobbers a
  hand-tuned site, preserves license keys, no-ops if plugin inactive or JSON missing.
- To refresh the bundled config: Perfmatters > Tools > Export on a tuned site, overwrite
  `assets/perfmatters/perfmatters-config.json`. See `assets/perfmatters/README.md`.
- NOTE: in this Perfmatters version Inline IS the default, so the export stores `rucss_method`
  as empty ("Inline (Default)"). The bundled config is the verbatim export (empty = Inline) -
  do not "fix" it to the literal string `inline`.
- Does NOT install the plugin itself (theme can't bundle a paid plugin). Perfmatters must be
  present on the site.
