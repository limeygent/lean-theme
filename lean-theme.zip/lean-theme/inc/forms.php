<?php
/**
 * Filename: lean-forms.php
 * Purpose: Complete contact form system with custom database table
 *
 * Features:
 * - Custom table for form submissions (lean_form_submissions)
 * - [lean_form] shortcode for frontend display
 * - AJAX form handling with honeypot + rate limiting
 * - Admin viewer with analytics, filtering, CSV export
 * - Legacy Ninja Forms migration tool
 *
 * Usage: require_once get_template_directory() . '/lean-forms.php';
 */

// ──────────────────────────────────────────────────────────────────────────────
// DATABASE TABLE SETUP
// ──────────────────────────────────────────────────────────────────────────────

// Campaign attribution helpers (lean_attribution_from_post / _label). lean-loader.php loads
// these ahead of us; the require keeps forms.php self-sufficient when it's dropped into
// another theme on its own, as the header above advertises.
require_once __DIR__ . '/attribution.php';

// Schema version. Bump whenever the table definition changes, and teach
// lean_forms_upgrade_schema() how to get an existing table from the old shape to the new one.
// 1.0 initial schema | 1.1 utm_source + utm_medium
if (!defined('LEAN_FORMS_DB_VERSION')) {
	define('LEAN_FORMS_DB_VERSION', '1.1');
}

/**
 * Get the submissions table name
 */
function lean_forms_table_name() {
	global $wpdb;
	return $wpdb->prefix . 'lean_form_submissions';
}

/**
 * Create the submissions table on theme activation
 */
function lean_forms_create_table() {
	global $wpdb;

	$table_name = lean_forms_table_name();
	$charset_collate = $wpdb->get_charset_collate();

	$sql = "CREATE TABLE {$table_name} (
		id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
		name varchar(255) NOT NULL,
		email varchar(255) NOT NULL,
		phone varchar(50) DEFAULT '',
		address text DEFAULT '',
		message text NOT NULL,
		page_slug varchar(255) NOT NULL DEFAULT '',
		page_title varchar(255) DEFAULT '',
		page_url varchar(255) DEFAULT '',
		referrer varchar(255) DEFAULT '',
		utm_source varchar(100) NOT NULL DEFAULT '',
		utm_medium varchar(100) NOT NULL DEFAULT '',
		ip_address varchar(45) DEFAULT '',
		user_agent text DEFAULT '',
		status varchar(20) NOT NULL DEFAULT 'new',
		is_spam tinyint(1) NOT NULL DEFAULT 0,
		is_read tinyint(1) NOT NULL DEFAULT 0,
		notes text DEFAULT '',
		meta longtext DEFAULT '',
		created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
		updated_at datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
		PRIMARY KEY (id),
		KEY page_slug (page_slug),
		KEY status (status),
		KEY is_spam (is_spam),
		KEY created_at (created_at),
		KEY email (email),
		KEY utm_source (utm_source)
	) {$charset_collate};";

	require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
	dbDelta($sql);

	// Store version for future migrations
	update_option('lean_forms_db_version', LEAN_FORMS_DB_VERSION);
}

/**
 * Bring an existing table up to the current schema.
 *
 * Deliberately a targeted ALTER rather than a second dbDelta() pass: the legacy columns are
 * `text DEFAULT ''`, which MySQL rejects, so dbDelta would try (and silently fail) to rewrite
 * them on every run. Adding only what's missing keeps the upgrade a single clean statement.
 *
 * @return void
 */
function lean_forms_upgrade_schema() {
	global $wpdb;
	$table = lean_forms_table_name();

	$columns = $wpdb->get_col("SHOW COLUMNS FROM {$table}");
	if (empty($columns)) {
		return;
	}

	// 1.0 → 1.1: campaign attribution
	if (!in_array('utm_source', $columns, true)) {
		$wpdb->query("ALTER TABLE {$table}
			ADD COLUMN utm_source varchar(100) NOT NULL DEFAULT '' AFTER referrer,
			ADD COLUMN utm_medium varchar(100) NOT NULL DEFAULT '' AFTER utm_source,
			ADD KEY utm_source (utm_source)");
	}
}

/**
 * Check and create/upgrade table if needed
 */
function lean_forms_maybe_create_table() {
	$installed_version = get_option('lean_forms_db_version', '0');

	if (version_compare($installed_version, LEAN_FORMS_DB_VERSION, '>=')) {
		return;
	}

	if (version_compare($installed_version, '1.0', '<')) {
		lean_forms_create_table(); // Fresh install — CREATE TABLE is already current.
	} else {
		lean_forms_upgrade_schema();
		update_option('lean_forms_db_version', LEAN_FORMS_DB_VERSION);
	}
}
add_action('after_setup_theme', 'lean_forms_maybe_create_table');

// ──────────────────────────────────────────────────────────────────────────────
// FORM SUBMISSION HANDLING
// ──────────────────────────────────────────────────────────────────────────────

// Register AJAX endpoints
add_action('wp_ajax_lean_contact_form', 'lean_forms_process_submission');
add_action('wp_ajax_nopriv_lean_contact_form', 'lean_forms_process_submission');

/**
 * Security: Generate form token
 */
function lean_forms_token_generate() {
	$salt = 'lean-form-' . get_home_url();
	return md5(date('Ymd') . $salt);
}

/**
 * Security: Verify form token
 */
function lean_forms_token_verify($token) {
	return $token === lean_forms_token_generate();
}

/**
 * The visitor's IP, as best we can tell.
 *
 * Behind Cloudflare, REMOTE_ADDR is an edge node — geolocating it would return the data
 * centre rather than the visitor — so CF-Connecting-IP wins when it's there. Cloudflare
 * strips any client-supplied copy of that header, so it's trustworthy on a CF site; on a
 * non-CF site a spoofer can only pollute their own stored record. Deliberately NOT used
 * for rate limiting, which stays on the unspoofable REMOTE_ADDR.
 *
 * @return string Validated IP, or '' if neither header holds one.
 */
function lean_forms_client_ip() {
	$candidates = array(
		$_SERVER['HTTP_CF_CONNECTING_IP'] ?? '',
		$_SERVER['REMOTE_ADDR'] ?? '',
	);

	foreach ($candidates as $ip) {
		$ip = trim($ip);
		if (filter_var($ip, FILTER_VALIDATE_IP)) {
			return $ip;
		}
	}

	return '';
}

/**
 * Resolve an IP to "City, Region, Country" so a submission's origin is readable at a glance.
 *
 * Best-effort by design: private/reserved addresses are skipped, results are cached per IP,
 * and every failure path returns '' — a slow or dead geo service must never cost us a lead.
 *
 * @param string $ip IPv4/IPv6 address.
 * @return string Formatted location, or '' when unavailable.
 */
function lean_forms_geolocate_ip($ip) {
	// Filterable so a site can swap providers (the value must contain a %s for the IP), or
	// pass '' to turn geolocation off entirely and stop visitor IPs leaving the server.
	$endpoint = apply_filters('lean_forms_geo_endpoint', 'https://ipwho.is/%s');

	if ($ip === '' || $endpoint === '') {
		return '';
	}

	// Localhost, LAN and reserved ranges have no location — don't spend a call on them.
	if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
		return '';
	}

	// A stored '' is a real cached answer, distinct from get_transient()'s false-for-missing.
	$cache_key = 'lean_geo_' . md5($ip);
	$cached = get_transient($cache_key);
	if ($cached !== false) {
		return $cached;
	}

	$response = wp_remote_get(sprintf($endpoint, rawurlencode($ip)), array(
		'timeout' => 2,
		'headers' => array('Accept' => 'application/json'),
	));

	$location = '';
	if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
		$data = json_decode(wp_remote_retrieve_body($response), true);
		if (is_array($data)) {
			$location = lean_forms_format_location($data);
		}
	}

	// Successes are worth keeping (IPs rarely move); failures get a short negative cache so a
	// blip doesn't blank out that visitor for a week.
	set_transient($cache_key, $location, $location !== '' ? WEEK_IN_SECONDS : HOUR_IN_SECONDS);

	return $location;
}

/**
 * Flatten a geo API's JSON into "City, Region, Country".
 *
 * Key aliases are what keep lean_forms_geo_endpoint genuinely swappable: ipwho.is returns
 * city/region/country, other keyless providers return cityName/regionName/countryName.
 *
 * @param array $data Decoded JSON response.
 * @return string
 */
function lean_forms_format_location($data) {
	// ipwho.is answers 200 with success=false for an unroutable or unknown address.
	if (isset($data['success']) && !$data['success']) {
		return '';
	}

	$pick = function($keys) use ($data) {
		foreach ($keys as $key) {
			if (!empty($data[$key]) && is_string($data[$key])) {
				return sanitize_text_field($data[$key]);
			}
		}
		return '';
	};

	$parts = array(
		$pick(array('city', 'cityName')),
		$pick(array('region', 'regionName')),
		$pick(array('country', 'countryName')),
	);

	return implode(', ', array_filter($parts));
}

/**
 * Security: Rate limiting
 */
function lean_forms_rate_limit_check() {
	$ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
	$key = 'lean_forms_rl_' . md5($ip);
	$hits = (int) get_transient($key);

	if ($hits > 10) {
		return false; // 10 submissions per hour per IP
	}

	set_transient($key, $hits + 1, HOUR_IN_SECONDS);
	return true;
}

/**
 * Process form submission
 */
function lean_forms_process_submission() {
	// Get config from options
	$config = array(
		'recipient'          => get_option('form_recipient_email', get_option('admin_email')),
		'company_name'       => get_option('business_name', get_bloginfo('name')),
		'from_email'         => get_option('form_from_email', get_option('admin_email')),
		'success_message'    => get_option('form_success_message', "Message sent. We'll contact you within 24 hours."),
		'error_message'      => get_option('form_error_message', 'Error sending message. Please call us directly.'),
		'send_confirmation'  => get_option('form_send_confirmation', false),
	);

	// Security: Token check
	if (!isset($_POST['token']) || !lean_forms_token_verify($_POST['token'])) {
		wp_send_json_error('Security validation failed. Please refresh and try again.');
	}

	// Security: Honeypot check
	if (!empty($_POST['website'])) {
		// Silently succeed to confuse bots
		wp_send_json_success($config['success_message']);
	}

	// Security: Rate limiting
	if (!lean_forms_rate_limit_check()) {
		wp_send_json_error('Too many submissions. Please try again later.');
	}

	// Sanitize fields
	$name       = sanitize_text_field($_POST['name'] ?? '');
	$email      = sanitize_email($_POST['email'] ?? '');
	$phone      = sanitize_text_field($_POST['phone'] ?? '');
	$address    = sanitize_text_field($_POST['address'] ?? '');
	$message    = sanitize_textarea_field($_POST['message'] ?? '');
	$page_slug  = sanitize_text_field($_POST['page_slug'] ?? '');
	$page_title = sanitize_text_field($_POST['page_title'] ?? '');

	// Validate required fields
	if (empty($name) || empty($email) || empty($message)) {
		wp_send_json_error('Please fill in all required fields.');
	}

	if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		wp_send_json_error('Please enter a valid email address.');
	}

	// Campaign attribution + visit path, stamped on the landing page by inc/attribution.php
	// and posted back by the form's submit handler. source/medium get their own columns
	// (they're listed and searched); the rest ride along in the meta JSON.
	$attribution = lean_attribution_from_post();
	$visit_path  = lean_attribution_path_from_post();

	// Resolve the IP to a place while we still have the request. Unlike UTMs this one is safe
	// server-side: the AJAX POST is never page-cached, so REMOTE_ADDR really is the submitter.
	$ip_address  = lean_forms_client_ip();
	$ip_location = lean_forms_geolocate_ip($ip_address);

	// Save to database - page_slug is the unique identifier
	$submission_id = lean_forms_save_submission(array(
		'name'       => $name,
		'email'      => $email,
		'phone'      => $phone,
		'address'    => $address,
		'message'    => $message,
		'page_slug'  => $page_slug,
		'page_title' => $page_title ?: $page_slug,
		'page_url'   => wp_get_referer() ?: '',
		'referrer'   => $_SERVER['HTTP_REFERER'] ?? '',
		'utm_source' => $attribution['source'],
		'utm_medium' => $attribution['medium'],
		'ip_address' => $ip_address,
		'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
		'meta'       => array_filter(array(
			'utm_campaign' => $attribution['campaign'],
			'utm_term'     => $attribution['term'],
			'utm_content'  => $attribution['content'],
			'click_id'     => $attribution['click_id'],
			'landing_page' => $attribution['landing_page'],
			'visit_path'   => $visit_path,
			'ip_location'  => $ip_location,
		)),
	));

	if (!$submission_id) {
		wp_send_json_error($config['error_message']);
	}

	// Send email notification
	$mail_sent = lean_forms_send_notification($submission_id, $config);

	// Send confirmation email if enabled
	if ($mail_sent && $config['send_confirmation']) {
		lean_forms_send_confirmation($email, $name, $config);
	}

	if ($mail_sent) {
		wp_send_json_success($config['success_message']);
	} else {
		// Still saved to DB, just email failed
		error_log('Lean Forms: Email failed but submission saved. ID: ' . $submission_id);
		wp_send_json_success($config['success_message']);
	}
}

/**
 * Save submission to database
 */
function lean_forms_save_submission($data) {
	global $wpdb;
	$table = lean_forms_table_name();

	$result = $wpdb->insert($table, array(
		'name'       => $data['name'],
		'email'      => $data['email'],
		'phone'      => $data['phone'] ?? '',
		'address'    => $data['address'] ?? '',
		'message'    => $data['message'],
		'page_slug'  => $data['page_slug'] ?? '',
		'page_title' => $data['page_title'] ?? '',
		'page_url'   => $data['page_url'] ?? '',
		'referrer'   => $data['referrer'] ?? '',
		'utm_source' => $data['utm_source'] ?? '',
		'utm_medium' => $data['utm_medium'] ?? '',
		'ip_address' => $data['ip_address'] ?? '',
		'user_agent' => $data['user_agent'] ?? '',
		'status'     => 'new',
		'is_spam'    => 0,
		'is_read'    => 0,
		'meta'       => !empty($data['meta']) ? json_encode($data['meta']) : '',
		'created_at' => current_time('mysql'),
	), array('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%d','%d','%s','%s'));

	if ($result === false) {
		error_log('Lean Forms DB Error: ' . $wpdb->last_error);
		return false;
	}

	return $wpdb->insert_id;
}

/**
 * Read one value out of a submission's meta JSON blob.
 *
 * @param object $submission Row from the submissions table.
 * @param string $key        Meta key, e.g. 'utm_campaign' (string) or 'visit_path' (array).
 * @param mixed  $default    Returned when the row predates the key or the blob is unreadable.
 * @return mixed
 */
function lean_forms_meta_value($submission, $key, $default = '') {
	if (empty($submission->meta)) {
		return $default;
	}

	$meta = json_decode($submission->meta, true);
	return is_array($meta) && isset($meta[$key]) ? $meta[$key] : $default;
}

/**
 * Send email notification to admin
 */
function lean_forms_send_notification($submission_id, $config) {
	global $wpdb;
	$table = lean_forms_table_name();

	$submission = $wpdb->get_row($wpdb->prepare(
		"SELECT * FROM {$table} WHERE id = %d",
		$submission_id
	));

	if (!$submission) {
		return false;
	}

	$subject = sprintf('[%s] New Contact Form Submission', $config['company_name']);

	$body = "New form submission received:\n\n";
	$body .= "Name: {$submission->name}\n";
	$body .= "Email: {$submission->email}\n";
	$body .= "Phone: {$submission->phone}\n";
	if (!empty($submission->address)) {
		$body .= "Address: {$submission->address}\n";
	}
	$body .= "\nMessage:\n{$submission->message}\n";
	$body .= "\n---\n";
	$body .= "Page: {$submission->page_title}\n";

	// Where the lead came from. Only printed when we actually captured it — leads submitted
	// before this shipped (or with JS-blocked cookies) shouldn't show an empty "Source:" line.
	if (!empty($submission->utm_source) || !empty($submission->utm_medium)) {
		$body .= 'Source: ' . lean_attribution_label($submission->utm_source, $submission->utm_medium) . "\n";

		$campaign = lean_forms_meta_value($submission, 'utm_campaign');
		if ($campaign !== '') {
			$body .= "Campaign: {$campaign}\n";
		}

		$landing = lean_forms_meta_value($submission, 'landing_page');
		if ($landing !== '') {
			$body .= "Landed on: {$landing}\n";
		}
	}

	// The route they took to the form — often the most useful line in the whole email.
	$visit_path = lean_forms_meta_value($submission, 'visit_path', array());
	$path_lines = lean_attribution_format_path($visit_path);
	if ($path_lines !== '') {
		$body .= "\nVisit path (" . lean_attribution_path_summary($visit_path) . "):\n";
		$body .= $path_lines . "\n";
	}

	$body .= "\nSubmitted: {$submission->created_at}\n";

	// IP with its resolved location — a lead from nowhere near the service area is the
	// cheapest spam tell there is. Appended only when the lookup actually returned something.
	$ip_location = lean_forms_meta_value($submission, 'ip_location');
	$body .= "IP: {$submission->ip_address}";
	$body .= $ip_location !== '' ? " ({$ip_location})\n" : "\n";
	$body .= "\nView in admin: " . admin_url('admin.php?page=lean-form-submissions&view=' . $submission_id);

	$headers = array(
		'From: ' . $config['company_name'] . ' <' . $config['from_email'] . '>',
		'Reply-To: ' . $submission->name . ' <' . $submission->email . '>',
		'Content-Type: text/plain; charset=UTF-8'
	);

	return wp_mail($config['recipient'], $subject, $body, $headers);
}

/**
 * Send confirmation email to submitter
 */
function lean_forms_send_confirmation($email, $name, $config) {
	$subject = 'Thank you for contacting ' . $config['company_name'];

	$body = "Hi {$name},\n\n";
	$body .= "Thank you for reaching out to us. We've received your message and will get back to you within 24 hours.\n\n";
	$body .= "Best regards,\n";
	$body .= $config['company_name'];

	$headers = array(
		'From: ' . $config['company_name'] . ' <' . $config['from_email'] . '>',
		'Content-Type: text/plain; charset=UTF-8'
	);

	return wp_mail($email, $subject, $body, $headers);
}

// ──────────────────────────────────────────────────────────────────────────────
// SHORTCODE: [lean_form]
// ──────────────────────────────────────────────────────────────────────────────

add_shortcode('lean_form', 'lean_forms_shortcode');

function lean_forms_shortcode($atts = array()) {
	$a = shortcode_atts(array(
		'button'      => 'Get My Quote',
		'class'       => 'btn-warning',
		'size'        => '',
		'show_phone'  => 'true',
		'show_address'=> 'false',
		'columns'     => '',

		// WebMCP (declarative). Annotations only — agent fills, user submits.
		// Emitted only when an Origin Trial token is configured (see lean_webmcp_enabled()).
		'webmcp'             => 'true',
		'webmcp_tool'        => 'request_service_estimate',
		'webmcp_description' => '',
	), $atts);

	$show_phone   = filter_var($a['show_phone'], FILTER_VALIDATE_BOOLEAN);
	$show_address = filter_var($a['show_address'], FILTER_VALIDATE_BOOLEAN);

	$ajax_url = admin_url('admin-ajax.php');
	$token = lean_forms_token_generate();

	// Get page context - this is the unique identifier for submissions
	global $post;
	$page_slug = '';
	$page_title = '';
	if (is_front_page() || is_home()) {
		$page_slug = 'home';
		$page_title = 'Home';
	} elseif ($post) {
		$page_slug = $post->post_name;
		$page_title = get_the_title($post->ID);
	}

	$btn_size = $a['size'] ? 'btn-' . $a['size'] : '';

	// Unique IDs so multiple [lean_form] instances on one page don't collide.
	static $lean_form_instance = 0;
	$lean_form_instance++;
	$form_id    = 'lean-form-' . $lean_form_instance;
	$wrapper_id = 'lean-form-wrapper-' . $lean_form_instance;

	// Declarative WebMCP <form> attributes (empty string when disabled/unavailable).
	$webmcp_attrs = '';
	if (filter_var($a['webmcp'], FILTER_VALIDATE_BOOLEAN) && function_exists('lean_webmcp_form_attrs')) {
		$webmcp_attrs = lean_webmcp_form_attrs(array(
			'tool'        => $a['webmcp_tool'],
			'description' => $a['webmcp_description'],
			'page_title'  => $page_title,
		));
	}
	// True only when WebMCP is actually emitting for this form (token present + not opted out).
	// When active, the honeypot is rendered off-schema so it never becomes a WebMCP tool param.
	$webmcp_active = ($webmcp_attrs !== '');

	ob_start();
	?>
	<?php if ($lean_form_instance === 1): // class-based, so only print the shared styles once ?>
	<style>
	.lean-form .hp { position: absolute; left: -9999px; }
	.lean-form .btn:disabled { opacity: 0.65; cursor: not-allowed; }
	.lean-form-wrapper .form-fields { transition: opacity 0.3s ease; }
	.lean-form-wrapper .form-fields.hiding { opacity: 0; }
	/* WebMCP: highlight the form while an agent is interacting with it. */
	form:tool-form-active { outline: 2px dashed currentColor; outline-offset: 4px; }
	</style>
	<?php endif; ?>

	<?php if ($a['columns']): ?>
	<div class="row justify-content-center">
	<div class="<?php echo esc_attr($a['columns']); ?>">
	<?php endif; ?>

	<div id="<?php echo esc_attr($wrapper_id); ?>" class="lean-form-wrapper">
		<form id="<?php echo esc_attr($form_id); ?>" class="lean-form needs-validation" novalidate
			  <?php echo $webmcp_attrs; ?>
			  data-page-slug="<?php echo esc_attr($page_slug); ?>"
			  data-page-title="<?php echo esc_attr($page_title); ?>">

			<div class="form-fields">
				<!-- Name -->
				<div class="form-group mb-3">
					<label for="<?php echo esc_attr($form_id); ?>-name" class="sr-only visually-hidden">Your name</label>
					<input type="text" id="<?php echo esc_attr($form_id); ?>-name" name="name" class="form-control"
						   placeholder="Your name *" required minlength="2"
						   autocomplete="name"<?php echo function_exists('lean_webmcp_param_attr') ? lean_webmcp_param_attr('name') : ''; ?>>
					<div class="invalid-feedback">Please enter your name</div>
				</div>

				<!-- Email -->
				<div class="form-group mb-3">
					<label for="<?php echo esc_attr($form_id); ?>-email" class="sr-only visually-hidden">Your email</label>
					<input type="email" id="<?php echo esc_attr($form_id); ?>-email" name="email" class="form-control"
						   placeholder="Your email *" required
						   autocomplete="email"<?php echo function_exists('lean_webmcp_param_attr') ? lean_webmcp_param_attr('email') : ''; ?>>
					<div class="invalid-feedback">Please enter a valid email</div>
				</div>

				<?php if ($show_phone): ?>
				<!-- Phone -->
				<div class="form-group mb-3">
					<label for="<?php echo esc_attr($form_id); ?>-phone" class="sr-only visually-hidden">Your phone</label>
					<input type="tel" id="<?php echo esc_attr($form_id); ?>-phone" name="phone" class="form-control"
						   placeholder="Your phone *" required minlength="10"
						   autocomplete="tel"<?php echo function_exists('lean_webmcp_param_attr') ? lean_webmcp_param_attr('phone') : ''; ?>>
					<div class="invalid-feedback">Please enter a valid phone number</div>
				</div>
				<?php endif; ?>

				<?php if ($show_address): ?>
				<!-- Address -->
				<div class="form-group mb-3">
					<label for="<?php echo esc_attr($form_id); ?>-address" class="sr-only visually-hidden">Service address</label>
					<input type="text" id="<?php echo esc_attr($form_id); ?>-address" name="address" class="form-control"
						   placeholder="Service address (optional)"
						   autocomplete="street-address"<?php echo function_exists('lean_webmcp_param_attr') ? lean_webmcp_param_attr('address') : ''; ?>>
				</div>
				<?php endif; ?>

				<!-- Message -->
				<div class="form-group mb-3">
					<label for="<?php echo esc_attr($form_id); ?>-message" class="sr-only visually-hidden">Your message</label>
					<textarea id="<?php echo esc_attr($form_id); ?>-message" name="message" class="form-control"
							  placeholder="How can we help you? *" required rows="4"<?php echo function_exists('lean_webmcp_param_attr') ? lean_webmcp_param_attr('message') : ''; ?>></textarea>
					<div class="invalid-feedback">Please enter your message</div>
				</div>

				<!-- Honeypot. When WebMCP is active the trap is rendered OFF-SCHEMA:
				     no `name` attribute (so it is never exposed as a WebMCP tool
				     parameter an agent could fill, which would silently discard a
				     real lead); the JS submit handler reads `data-hp` and appends
				     the value as `website`. When WebMCP is inactive we keep the
				     classic named honeypot for maximum non-JS-bot coverage. -->
				<div class="hp" aria-hidden="true">
					<input type="text" <?php echo $webmcp_active ? 'data-hp="website"' : 'name="website"'; ?> tabindex="-1" autocomplete="off">
				</div>

				<!-- Submit -->
				<button type="submit" class="btn <?php echo esc_attr($a['class'] . ' ' . $btn_size); ?> btn-block w-100">
					<span class="btn-text"><?php echo esc_html($a['button']); ?></span>
					<span class="spinner-border spinner-border-sm ms-2 d-none" role="status"></span>
				</button>
			</div>
		</form>

		<div class="form-message alert mt-3 d-none"></div>
	</div>

	<?php if ($a['columns']): ?>
	</div>
	</div>
	<?php endif; ?>

	<script>
	(function() {
		var form = document.getElementById('<?php echo esc_js($form_id); ?>');
		if (!form || form.dataset.initialized) return;
		form.dataset.initialized = 'true';

		var wrapper = document.getElementById('<?php echo esc_js($wrapper_id); ?>');
		var fields = form.querySelector('.form-fields');
		var msg = wrapper.querySelector('.form-message');
		var btn = form.querySelector('button[type="submit"]');
		var btnText = btn.querySelector('.btn-text');
		var spinner = btn.querySelector('.spinner-border');
		var originalText = btnText.textContent;

		form.addEventListener('submit', function(e) {
			e.preventDefault();

			if (!form.checkValidity()) {
				form.classList.add('was-validated');
				return;
			}

			btn.disabled = true;
			btnText.textContent = 'Sending...';
			spinner.classList.remove('d-none');
			msg.className = 'form-message alert mt-3 d-none';

			var data = new FormData();
			data.append('action', 'lean_contact_form');
			data.append('token', '<?php echo $token; ?>');
			data.append('page_slug', form.dataset.pageSlug);
			data.append('page_title', form.dataset.pageTitle);
			data.append('name', form.querySelector('[name="name"]').value);
			data.append('email', form.querySelector('[name="email"]').value);
			data.append('message', form.querySelector('[name="message"]').value);
			// Honeypot: named when WebMCP is off, off-schema (data-hp) when WebMCP is on.
			var hp = form.querySelector('[name="website"], [data-hp="website"]');
			data.append('website', hp ? hp.value : '');

			// Campaign attribution + visit path, stamped on the landing page by
			// inc/attribution.php. The query string is long gone by the time a visitor
			// reaches the form, so this is the only place these values can come from.
			var attr = (typeof window.leanAttribution === 'function') ? window.leanAttribution() : null;
			if (attr) {
				data.append('utm_source', attr.s || '');
				data.append('utm_medium', attr.m || '');
				data.append('utm_campaign', attr.c || '');
				data.append('utm_term', attr.t || '');
				data.append('utm_content', attr.n || '');
				data.append('click_id', attr.k || '');
				data.append('landing_page', attr.l || '');
			}

			var path = (typeof window.leanVisitPath === 'function') ? window.leanVisitPath() : null;
			if (path && path.length) data.append('visit_path', JSON.stringify(path));

			var phone = form.querySelector('[name="phone"]');
			if (phone) data.append('phone', phone.value);

			var address = form.querySelector('[name="address"]');
			if (address) data.append('address', address.value);

			fetch('<?php echo $ajax_url; ?>', {
				method: 'POST',
				body: data
			})
			.then(function(r) { return r.json(); })
			.then(function(result) {
				msg.className = 'form-message alert alert-' + (result.success ? 'success' : 'danger') + ' mt-3';

				if (result.success) {
					fields.classList.add('hiding');
					setTimeout(function() {
						fields.style.display = 'none';
						msg.innerHTML = '<strong>Thank You!</strong><br>' + (result.data || '');
					}, 300);

					// Track only a server-confirmed successful submission.
					window.dataLayer = window.dataLayer || [];
					window.dataLayer.push({
						event: 'lead_form_success',
						form_id: (form.dataset.pageSlug || 'unknown') + '-contact',
						form_name: (form.dataset.pageTitle || 'Contact') + ' contact form',
						lead_type: 'form'
					});

					// GA4-only sites: gtag.js ignores the plain push above, so send the event
					// directly. The theme only defines gtag when no GTM ID is set, so a GTM
					// site never reaches this and can't double-count.
					if (typeof gtag === 'function') {
						gtag('event', 'generate_lead', {
							'event_category': 'contact',
							'event_label': form.dataset.pageSlug
						});
					}

				} else {
					msg.textContent = result.data || 'An error occurred';
					btn.disabled = false;
					btnText.textContent = originalText;
					spinner.classList.add('d-none');
				}
			})
			.catch(function() {
				msg.className = 'form-message alert alert-danger mt-3';
				msg.textContent = 'Network error. Please try again.';
				btn.disabled = false;
				btnText.textContent = originalText;
				spinner.classList.add('d-none');
			});
		});
	})();
	</script>
	<?php
	return ob_get_clean();
}

// ──────────────────────────────────────────────────────────────────────────────
// ADMIN: Submissions Viewer
// ──────────────────────────────────────────────────────────────────────────────

add_action('admin_menu', 'lean_forms_admin_menu');

function lean_forms_admin_menu() {
	add_menu_page(
		'Form Submissions',
		'Form Submissions',
		'manage_options',
		'lean-form-submissions',
		'lean_forms_admin_page',
		'dashicons-email-alt',
		30
	);
}

// Load Chart.js on admin page
add_action('admin_enqueue_scripts', function($hook) {
	if ($hook !== 'toplevel_page_lean-form-submissions') return;
	wp_enqueue_script('chartjs', 'https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js', array(), '4.4.0', true);
});

// AJAX handlers for admin actions
add_action('wp_ajax_lean_forms_mark_spam', 'lean_forms_ajax_mark_spam');
add_action('wp_ajax_lean_forms_delete', 'lean_forms_ajax_delete');
add_action('wp_ajax_lean_forms_mark_read', 'lean_forms_ajax_mark_read');

function lean_forms_ajax_mark_spam() {
	if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

	$id = intval($_POST['id'] ?? 0);
	$is_spam = intval($_POST['is_spam'] ?? 1);

	if (!wp_verify_nonce($_POST['nonce'] ?? '', 'lean_forms_action_' . $id)) {
		wp_send_json_error('Security check failed');
	}

	global $wpdb;
	$table = lean_forms_table_name();
	$wpdb->update($table, array('is_spam' => $is_spam), array('id' => $id), array('%d'), array('%d'));

	wp_send_json_success($is_spam ? 'Marked as spam' : 'Marked as not spam');
}

function lean_forms_ajax_delete() {
	if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

	$id = intval($_POST['id'] ?? 0);

	if (!wp_verify_nonce($_POST['nonce'] ?? '', 'lean_forms_action_' . $id)) {
		wp_send_json_error('Security check failed');
	}

	global $wpdb;
	$table = lean_forms_table_name();
	$wpdb->delete($table, array('id' => $id), array('%d'));

	wp_send_json_success('Deleted');
}

function lean_forms_ajax_mark_read() {
	if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

	$id = intval($_POST['id'] ?? 0);

	global $wpdb;
	$table = lean_forms_table_name();
	$wpdb->update($table, array('is_read' => 1), array('id' => $id), array('%d'), array('%d'));

	wp_send_json_success('Marked as read');
}

/**
 * Get analytics data
 */
function lean_forms_get_analytics($start_date = null, $end_date = null) {
	global $wpdb;
	$table = lean_forms_table_name();

	$where = "WHERE is_spam = 0";
	if ($start_date) $where .= $wpdb->prepare(" AND created_at >= %s", $start_date);
	if ($end_date) $where .= $wpdb->prepare(" AND created_at <= %s", $end_date);

	// Monthly breakdown
	$monthly = $wpdb->get_results("
		SELECT
			DATE_FORMAT(created_at, '%Y-%m') as month,
			YEAR(created_at) as year,
			MONTH(created_at) as month_num,
			COUNT(*) as total
		FROM {$table}
		{$where}
		GROUP BY DATE_FORMAT(created_at, '%Y-%m')
		ORDER BY month DESC
	");

	// By page (slug is the unique identifier)
	$by_page = $wpdb->get_results("
		SELECT page_slug, page_title, COUNT(*) as total
		FROM {$table}
		{$where}
		AND page_slug != ''
		GROUP BY page_slug
		ORDER BY total DESC
		LIMIT 20
	");

	return array(
		'monthly' => $monthly,
		'by_page' => $by_page,
	);
}

/**
 * Admin page rendering
 */
function lean_forms_admin_page() {
	global $wpdb;
	$table = lean_forms_table_name();

	// Check if table exists
	if ($wpdb->get_var("SHOW TABLES LIKE '{$table}'") !== $table) {
		echo '<div class="wrap"><h1>Form Submissions</h1>';
		echo '<div class="notice notice-warning"><p>Database table not found. ';
		echo '<a href="' . admin_url('admin.php?page=lean-form-submissions&action=create_table') . '" class="button">Create Table</a></p></div>';
		echo '</div>';

		if (isset($_GET['action']) && $_GET['action'] === 'create_table') {
			lean_forms_create_table();
			echo '<div class="notice notice-success"><p>Table created successfully!</p></div>';
		}
		return;
	}

	// Handle CSV export
	if (isset($_GET['export']) && $_GET['export'] === 'csv') {
		lean_forms_export_csv();
		exit;
	}

	// Filters
	$spam_filter = isset($_GET['spam']) ? sanitize_text_field($_GET['spam']) : 'not_spam';
	$search = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
	$paged = max(1, intval($_GET['paged'] ?? 1));
	$per_page = 50;
	$offset = ($paged - 1) * $per_page;

	// Build query
	$where = "WHERE 1=1";
	if ($spam_filter === 'spam') {
		$where .= " AND is_spam = 1";
	} elseif ($spam_filter === 'not_spam') {
		$where .= " AND is_spam = 0";
	}

	if (!empty($search)) {
		$like = '%' . $wpdb->esc_like($search) . '%';
		$where .= $wpdb->prepare(" AND (name LIKE %s OR email LIKE %s OR message LIKE %s OR phone LIKE %s OR utm_source LIKE %s)", $like, $like, $like, $like, $like);
	}

	$total = $wpdb->get_var("SELECT COUNT(*) FROM {$table} {$where}");
	$total_pages = ceil($total / $per_page);

	$submissions = $wpdb->get_results("
		SELECT * FROM {$table}
		{$where}
		ORDER BY created_at DESC
		LIMIT {$per_page} OFFSET {$offset}
	");

	$spam_count = $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE is_spam = 1");
	$new_count = $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE is_read = 0 AND is_spam = 0");

	// Get analytics
	$analytics = lean_forms_get_analytics();

	// Calculate YTD
	$current_year = date('Y');
	$ytd_total = 0;
	$last_year_total = 0;
	foreach ($analytics['monthly'] as $row) {
		if ((int)$row->year === (int)$current_year) {
			$ytd_total += $row->total;
		}
		if ((int)$row->year === (int)$current_year - 1) {
			$last_year_total += $row->total;
		}
	}

	?>
	<div class="wrap">
		<h1>Form Submissions <?php if ($new_count): ?><span class="badge" style="background:#0073aa;color:#fff;padding:2px 8px;border-radius:3px;font-size:12px;"><?php echo $new_count; ?> new</span><?php endif; ?></h1>

		<!-- Stats Row -->
		<div style="display:flex;gap:20px;margin:20px 0;">
			<div style="background:#fff;padding:15px 25px;border:1px solid #ccd0d4;border-left:4px solid #0073aa;">
				<div style="font-size:11px;color:#666;text-transform:uppercase;">Year to Date</div>
				<div style="font-size:28px;font-weight:bold;color:#0073aa;"><?php echo number_format($ytd_total); ?></div>
			</div>
			<div style="background:#fff;padding:15px 25px;border:1px solid #ccd0d4;">
				<div style="font-size:11px;color:#666;text-transform:uppercase;">Last Year Total</div>
				<div style="font-size:28px;font-weight:bold;"><?php echo number_format($last_year_total); ?></div>
			</div>
			<div style="background:#fff;padding:15px 25px;border:1px solid #ccd0d4;">
				<div style="font-size:11px;color:#666;text-transform:uppercase;">Spam</div>
				<div style="font-size:28px;font-weight:bold;color:#dc3545;"><?php echo number_format($spam_count); ?></div>
			</div>
		</div>

		<!-- Filters -->
		<div class="tablenav top">
			<div class="alignleft actions">
				<a href="?page=lean-form-submissions" class="button <?php echo $spam_filter === 'not_spam' ? 'button-primary' : ''; ?>">Inbox</a>
				<a href="?page=lean-form-submissions&spam=spam" class="button <?php echo $spam_filter === 'spam' ? 'button-primary' : ''; ?>">Spam (<?php echo $spam_count; ?>)</a>
				<a href="?page=lean-form-submissions&spam=all" class="button <?php echo $spam_filter === 'all' ? 'button-primary' : ''; ?>">All</a>

				<form method="get" style="display:inline-block;margin-left:10px;">
					<input type="hidden" name="page" value="lean-form-submissions">
					<input type="search" name="s" value="<?php echo esc_attr($search); ?>" placeholder="Search...">
					<input type="submit" class="button" value="Search">
				</form>

				<a href="?page=lean-form-submissions&export=csv&spam=<?php echo $spam_filter; ?>&s=<?php echo urlencode($search); ?>" class="button" style="margin-left:10px;">Export CSV</a>
			</div>

			<?php if ($total_pages > 1): ?>
			<div class="tablenav-pages">
				<span class="displaying-num"><?php echo number_format($total); ?> items</span>
				<?php
				echo paginate_links(array(
					'base' => add_query_arg('paged', '%#%'),
					'format' => '',
					'total' => $total_pages,
					'current' => $paged,
					'prev_text' => '&laquo;',
					'next_text' => '&raquo;',
				));
				?>
			</div>
			<?php endif; ?>
		</div>

		<!-- Table -->
		<table class="wp-list-table widefat fixed striped">
			<thead>
				<tr>
					<th style="width:140px;">Date</th>
					<th>Name</th>
					<th>Email</th>
					<th>Phone</th>
					<th>Page</th>
					<th style="width:150px;">Source</th>
					<th style="width:180px;">Actions</th>
				</tr>
			</thead>
			<tbody>
				<?php if (empty($submissions)): ?>
				<tr><td colspan="7" style="text-align:center;padding:40px;">No submissions found.</td></tr>
				<?php else: ?>
				<?php foreach ($submissions as $sub): ?>
				<tr id="row-<?php echo $sub->id; ?>" <?php echo $sub->is_spam ? 'style="background:#fee;"' : ''; ?> <?php echo !$sub->is_read ? 'style="font-weight:bold;"' : ''; ?>>
					<td><?php echo esc_html(date('M j, Y g:i A', strtotime($sub->created_at))); ?></td>
					<td><?php echo esc_html($sub->name); ?></td>
					<td><a href="mailto:<?php echo esc_attr($sub->email); ?>"><?php echo esc_html($sub->email); ?></a></td>
					<td><?php echo esc_html($sub->phone ?: '-'); ?></td>
					<td><?php echo esc_html($sub->page_title ?: '-'); ?></td>
					<td><?php echo esc_html(lean_attribution_label($sub->utm_source ?? '', $sub->utm_medium ?? '')); ?></td>
					<td>
						<a href="#" class="button button-small" onclick="event.preventDefault();toggleDetail(<?php echo $sub->id; ?>);">View</a>
						<?php if ($sub->is_spam): ?>
						<a href="#" class="button button-small" data-id="<?php echo $sub->id; ?>" data-action="not_spam" data-nonce="<?php echo wp_create_nonce('lean_forms_action_'.$sub->id); ?>" onclick="event.preventDefault();leanFormsAction(this,'not_spam');">Not Spam</a>
						<?php else: ?>
						<a href="#" class="button button-small" data-id="<?php echo $sub->id; ?>" data-action="spam" data-nonce="<?php echo wp_create_nonce('lean_forms_action_'.$sub->id); ?>" onclick="event.preventDefault();leanFormsAction(this,'spam');">Spam</a>
						<?php endif; ?>
						<a href="#" class="button button-small" style="color:#b32d2e;" data-id="<?php echo $sub->id; ?>" data-nonce="<?php echo wp_create_nonce('lean_forms_action_'.$sub->id); ?>" onclick="event.preventDefault();if(confirm('Delete permanently?'))leanFormsAction(this,'delete');">Delete</a>
					</td>
				</tr>
				<tr id="detail-<?php echo $sub->id; ?>" style="display:none;">
					<td colspan="7" style="background:#f9f9f9;padding:20px;">
						<div style="display:grid;grid-template-columns:1fr 1fr;gap:15px;">
							<div><strong>Name:</strong><br><?php echo esc_html($sub->name); ?></div>
							<div><strong>Email:</strong><br><a href="mailto:<?php echo esc_attr($sub->email); ?>"><?php echo esc_html($sub->email); ?></a></div>
							<div><strong>Phone:</strong><br><?php echo esc_html($sub->phone ?: '-'); ?></div>
							<div><strong>Address:</strong><br><?php echo esc_html($sub->address ?: '-'); ?></div>
							<div style="grid-column:1/-1;"><strong>Message:</strong><br><pre style="white-space:pre-wrap;margin:0;background:#fff;padding:10px;border:1px solid #ddd;"><?php echo esc_html($sub->message); ?></pre></div>

							<?php
							// Where the lead came from and how they got to the form. Hidden entirely
							// for rows captured before attribution shipped, so old leads stay clean.
							$sub_path     = lean_forms_meta_value($sub, 'visit_path', array());
							$sub_campaign = lean_forms_meta_value($sub, 'utm_campaign');
							$sub_landing  = lean_forms_meta_value($sub, 'landing_page');
							$sub_click    = lean_forms_meta_value($sub, 'click_id');
							$sub_source   = $sub->utm_source ?? '';
							$sub_medium   = $sub->utm_medium ?? '';
							?>
							<?php if ($sub_source || $sub_medium || $sub_path): ?>
							<div style="grid-column:1/-1;">
								<strong>Attribution:</strong>
								<div style="background:#fff;padding:10px;border:1px solid #ddd;">
									<div><?php echo esc_html(lean_attribution_label($sub_source, $sub_medium)); ?>
										<?php if ($sub_campaign !== ''): ?>
										&mdash; campaign: <?php echo esc_html($sub_campaign); ?>
										<?php endif; ?>
										<?php if ($sub_click !== ''): ?>
										<span style="color:#666;font-size:11px;">(click id: <?php echo esc_html($sub_click); ?>)</span>
										<?php endif; ?>
									</div>
									<?php if ($sub_landing !== ''): ?>
									<div style="color:#666;font-size:12px;">Landed on <?php echo esc_html($sub_landing); ?></div>
									<?php endif; ?>

									<?php if ($sub_path): ?>
									<div style="margin-top:8px;"><strong style="font-size:12px;">Visit path</strong>
										<span style="color:#666;font-size:12px;">(<?php echo esc_html(lean_attribution_path_summary($sub_path)); ?>)</span>
										<pre style="white-space:pre-wrap;margin:4px 0 0;font-size:12px;"><?php echo esc_html(lean_attribution_format_path($sub_path)); ?></pre>
									</div>
									<?php endif; ?>
								</div>
							</div>
							<?php endif; ?>
						</div>
						<div style="margin-top:15px;padding-top:15px;border-top:1px solid #ddd;color:#666;font-size:12px;">
							<strong>ID:</strong> <?php echo $sub->id; ?> |
							<strong>Page:</strong> <?php echo esc_html($sub->page_title ?: $sub->page_slug); ?> (<?php echo esc_html($sub->page_slug); ?>) |
							<strong>IP:</strong> <?php
								echo esc_html($sub->ip_address);
								$sub_location = lean_forms_meta_value($sub, 'ip_location');
								if ($sub_location !== '') {
									echo ' (' . esc_html($sub_location) . ')';
								}
							?> |
							<strong>Submitted:</strong> <?php echo $sub->created_at; ?>
						</div>
					</td>
				</tr>
				<?php endforeach; ?>
				<?php endif; ?>
			</tbody>
		</table>
	</div>

	<script>
	function toggleDetail(id) {
		var row = document.getElementById('detail-' + id);
		row.style.display = row.style.display === 'none' ? 'table-row' : 'none';

		// Mark as read
		fetch(ajaxurl, {
			method: 'POST',
			headers: {'Content-Type': 'application/x-www-form-urlencoded'},
			body: 'action=lean_forms_mark_read&id=' + id
		});
	}

	function leanFormsAction(btn, action) {
		var id = btn.dataset.id;
		var nonce = btn.dataset.nonce;
		var row = document.getElementById('row-' + id);
		var detail = document.getElementById('detail-' + id);

		btn.disabled = true;
		btn.textContent = '...';

		var ajaxAction = action === 'delete' ? 'lean_forms_delete' : 'lean_forms_mark_spam';
		var body = 'action=' + ajaxAction + '&id=' + id + '&nonce=' + nonce;
		if (action !== 'delete') body += '&is_spam=' + (action === 'spam' ? 1 : 0);

		fetch(ajaxurl, {
			method: 'POST',
			headers: {'Content-Type': 'application/x-www-form-urlencoded'},
			body: body
		})
		.then(function(r) { return r.json(); })
		.then(function(result) {
			if (result.success) {
				row.style.opacity = '0';
				setTimeout(function() {
					row.remove();
					if (detail) detail.remove();
				}, 300);
			} else {
				alert(result.data || 'Error');
				btn.disabled = false;
			}
		});
	}
	</script>

	<style>
	#row-<?php /* dynamic */ ?> { transition: opacity 0.3s; }
	.tablenav { margin: 15px 0; }
	</style>
	<?php
}

/**
 * Export submissions to CSV
 */
function lean_forms_export_csv() {
	if (!current_user_can('manage_options')) {
		wp_die('Unauthorized');
	}

	global $wpdb;
	$table = lean_forms_table_name();

	$spam_filter = sanitize_text_field($_GET['spam'] ?? 'not_spam');
	$search = sanitize_text_field($_GET['s'] ?? '');

	$where = "WHERE 1=1";
	if ($spam_filter === 'spam') {
		$where .= " AND is_spam = 1";
	} elseif ($spam_filter === 'not_spam') {
		$where .= " AND is_spam = 0";
	}

	if (!empty($search)) {
		$like = '%' . $wpdb->esc_like($search) . '%';
		$where .= $wpdb->prepare(" AND (name LIKE %s OR email LIKE %s OR message LIKE %s OR utm_source LIKE %s)", $like, $like, $like, $like);
	}

	$submissions = $wpdb->get_results("SELECT * FROM {$table} {$where} ORDER BY created_at DESC");

	header('Content-Type: text/csv; charset=utf-8');
	header('Content-Disposition: attachment; filename="form-submissions-' . date('Y-m-d') . '.csv"');

	$output = fopen('php://output', 'w');
	fputcsv($output, array('ID', 'Date', 'Name', 'Email', 'Phone', 'Address', 'Message', 'Page Slug', 'Page Title', 'UTM Source', 'UTM Medium', 'UTM Campaign', 'Landing Page', 'Visit Path', 'IP', 'IP Location', 'Spam'));

	foreach ($submissions as $sub) {
		// Path as "/ > /services/ > /contact/" — one cell, still readable in a spreadsheet.
		$path = lean_forms_meta_value($sub, 'visit_path', array());
		$path = $path ? implode(' > ', wp_list_pluck($path, 'u')) : '';

		fputcsv($output, array(
			$sub->id,
			$sub->created_at,
			$sub->name,
			$sub->email,
			$sub->phone,
			$sub->address,
			$sub->message,
			$sub->page_slug,
			$sub->page_title,
			$sub->utm_source ?? '',
			$sub->utm_medium ?? '',
			lean_forms_meta_value($sub, 'utm_campaign'),
			lean_forms_meta_value($sub, 'landing_page'),
			$path,
			$sub->ip_address,
			lean_forms_meta_value($sub, 'ip_location'),
			$sub->is_spam ? 'Yes' : 'No'
		));
	}

	fclose($output);
}

