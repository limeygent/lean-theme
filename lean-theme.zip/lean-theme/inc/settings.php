<?php
/**
 * Filename: settings.php
 * Purpose: Lean Theme settings page and shortcodes
 *
 * Creates: Theme Settings (top-level menu below Dashboard)
 * Includes all business info, analytics, form settings, and shortcodes
 */

// ──────────────────────────────────────────────────────────────────────────────
// ADMIN MENU & PAGE
// ──────────────────────────────────────────────────────────────────────────────

add_action('admin_menu', 'lean_theme_add_settings_page');

function lean_theme_add_settings_page() {
	add_menu_page(
		'Theme Settings',           // Page title
		'Theme Settings',           // Menu title
		'manage_options',           // Capability
		'lean-theme-settings',      // Menu slug
		'lean_theme_settings_page', // Callback function
		'dashicons-admin-customizer', // Icon
		2.1                         // Position (after Dashboard at 2, before other items at 3+)
	);
}

function lean_theme_settings_page() {
	if (!current_user_can('manage_options')) {
		return;
	}

	// Save settings if form submitted
	if (isset($_POST['lean_theme_nonce']) && wp_verify_nonce($_POST['lean_theme_nonce'], 'lean_theme_save_settings')) {
		lean_theme_save_settings();
		echo '<div class="notice notice-success"><p>Settings saved.</p></div>';
	}

	// Get current tab
	$active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'business';
	?>
	<div class="wrap">
		<h1>Lean Theme Settings</h1>

		<nav class="nav-tab-wrapper">
			<a href="?page=lean-theme-settings&tab=business" class="nav-tab <?php echo $active_tab === 'business' ? 'nav-tab-active' : ''; ?>">Business Info</a>
			<a href="?page=lean-theme-settings&tab=appearance" class="nav-tab <?php echo $active_tab === 'appearance' ? 'nav-tab-active' : ''; ?>">Appearance</a>
			<a href="?page=lean-theme-settings&tab=analytics" class="nav-tab <?php echo $active_tab === 'analytics' ? 'nav-tab-active' : ''; ?>">Analytics</a>
			<a href="?page=lean-theme-settings&tab=forms" class="nav-tab <?php echo $active_tab === 'forms' ? 'nav-tab-active' : ''; ?>">Contact Form</a>
			<a href="?page=lean-theme-settings&tab=booking" class="nav-tab <?php echo $active_tab === 'booking' ? 'nav-tab-active' : ''; ?>">Booking</a>
			<a href="?page=lean-theme-settings&tab=hours" class="nav-tab <?php echo $active_tab === 'hours' ? 'nav-tab-active' : ''; ?>">Hours</a>
			<a href="?page=lean-theme-settings&tab=shortcodes" class="nav-tab <?php echo $active_tab === 'shortcodes' ? 'nav-tab-active' : ''; ?>">Shortcodes</a>
		</nav>

		<form method="post" action="">
			<?php wp_nonce_field('lean_theme_save_settings', 'lean_theme_nonce'); ?>
			<input type="hidden" name="active_tab" value="<?php echo esc_attr($active_tab); ?>">

			<table class="form-table" role="presentation">
				<?php
				switch ($active_tab) {
					case 'business':
						lean_theme_business_fields();
						break;
					case 'appearance':
						lean_theme_appearance_fields();
						break;
					case 'analytics':
						lean_theme_analytics_fields();
						break;
					case 'forms':
						lean_theme_form_fields();
						break;
					case 'booking':
						lean_theme_booking_fields();
						break;
					case 'hours':
						lean_theme_hours_fields();
						break;
					case 'shortcodes':
						lean_theme_shortcodes_reference();
						break;
				}
				?>
			</table>

			<?php if ($active_tab !== 'shortcodes'): ?>
			<?php submit_button('Save Settings'); ?>
			<?php endif; ?>
		</form>
	</div>
	<?php
}

// ──────────────────────────────────────────────────────────────────────────────
// SETTINGS FIELDS BY TAB
// ──────────────────────────────────────────────────────────────────────────────

function lean_theme_business_fields() {
	?>
	<tr>
		<th scope="row"><label for="business_name">Business Name</label></th>
		<td><input type="text" name="business_name" id="business_name" value="<?php echo esc_attr(get_option('business_name', '')); ?>" class="regular-text"></td>
	</tr>
	<tr>
		<th scope="row"><label for="header_tagline">Header Tagline</label></th>
		<td>
			<input type="text" name="header_tagline" id="header_tagline" value="<?php echo esc_attr(get_option('header_tagline', '')); ?>" class="large-text">
			<p class="description">Displayed in the top header bar on desktop (when mode is set to "Tagline")</p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="business_url">Website URL</label></th>
		<td><input type="url" name="business_url" id="business_url" value="<?php echo esc_attr(get_option('business_url', home_url())); ?>" class="regular-text"></td>
	</tr>
	<tr>
		<th scope="row"><label for="business_phone">Phone Number</label></th>
		<td><input type="text" name="business_phone" id="business_phone" value="<?php echo esc_attr(get_option('business_phone', '')); ?>" class="regular-text" placeholder="(555) 555-5555"></td>
	</tr>
	<tr>
		<th scope="row"><label for="business_email">Public Email</label></th>
		<td>
			<input type="email" name="business_email" id="business_email" value="<?php echo esc_attr(get_option('business_email', '')); ?>" class="regular-text" placeholder="info@example.com">
			<p class="description">Public-facing contact email. Shown in legal pages and the <code>[business_email]</code> shortcode.</p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="business_address">Street Address</label></th>
		<td><input type="text" name="business_address" id="business_address" value="<?php echo esc_attr(get_option('business_address', '')); ?>" class="regular-text"></td>
	</tr>
	<tr>
		<th scope="row"><label for="business_city">City</label></th>
		<td><input type="text" name="business_city" id="business_city" value="<?php echo esc_attr(get_option('business_city', '')); ?>" class="regular-text"></td>
	</tr>
	<tr>
		<th scope="row"><label for="business_state">State</label></th>
		<td>
			<input type="text" name="business_state" id="business_state" value="<?php echo esc_attr(get_option('business_state', '')); ?>" class="regular-text" placeholder="Texas (or TX)">
			<p class="description">Full state name or 2-letter abbreviation. Legal pages will expand abbreviations to the full name automatically.</p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="business_county">County</label></th>
		<td>
			<input type="text" name="business_county" id="business_county" value="<?php echo esc_attr(get_option('business_county', '')); ?>" class="regular-text" placeholder="Collin">
			<p class="description">Used in the Terms of Use jurisdiction clause. Optional — if blank, venue is set at the state level only.</p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="business_zip">ZIP Code</label></th>
		<td><input type="text" name="business_zip" id="business_zip" value="<?php echo esc_attr(get_option('business_zip', '')); ?>" class="small-text" maxlength="10"></td>
	</tr>
	<tr>
		<th scope="row"><label for="google_maps_cid">Google Maps CID</label></th>
		<td>
			<input type="text" name="google_maps_cid" id="google_maps_cid" value="<?php echo esc_attr(get_option('google_maps_cid', '')); ?>" class="regular-text">
			<p class="description">Your Google Business Profile CID (used if embed URL not set)</p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="google_maps_embed_url">Google Maps Embed URL</label></th>
		<td>
			<input type="url" name="google_maps_embed_url" id="google_maps_embed_url" value="<?php echo esc_attr(get_option('google_maps_embed_url', '')); ?>" class="large-text">
			<p class="description">Full embed URL from Google Maps (takes priority over CID)</p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="google_kgid">Google Knowledge Graph ID</label></th>
		<td><input type="text" name="google_kgid" id="google_kgid" value="<?php echo esc_attr(get_option('google_kgid', '')); ?>" class="regular-text"></td>
	</tr>
	<tr>
		<th scope="row"><label for="google_gmb_image_url">GMB Image URL</label></th>
		<td>
			<input type="url" name="google_gmb_image_url" id="google_gmb_image_url" value="<?php echo esc_attr(get_option('google_gmb_image_url', '')); ?>" class="large-text" placeholder="https://...">
			<p class="description">Google My Business profile image URL (for map overlay)</p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="lean_default_language">Default Site Language</label></th>
		<td>
			<?php $current_lang = get_option('lean_default_language', 'en-US'); ?>
			<select name="lean_default_language" id="lean_default_language">
				<option value="en-US" <?php selected($current_lang, 'en-US'); ?>>English (United States) — en-US</option>
				<option value="en-GB" <?php selected($current_lang, 'en-GB'); ?>>English (United Kingdom) — en-GB</option>
				<option value="en-AU" <?php selected($current_lang, 'en-AU'); ?>>English (Australia) — en-AU</option>
				<option value="es"    <?php selected($current_lang, 'es');    ?>>Spanish — es (generic, inclusive of all variants)</option>
				<option value="es-MX" <?php selected($current_lang, 'es-MX'); ?>>Spanish (Mexico) — es-MX</option>
			</select>
			<p class="description">
				Sets the <code>&lt;html lang&gt;</code>, <code>hreflang</code>, <code>og:locale</code>, and <code>dc.language</code> values for every page.
				Override per page from the SEO Settings meta box.
			</p>
		</td>
	</tr>
	<?php
}

function lean_theme_appearance_fields() {
	$header_top_mode = get_option('header_top_mode', 'tagline');
	$header_top_items = get_option('header_top_items', []);
	if (!is_array($header_top_items)) $header_top_items = [];
	?>

	<tr><td colspan="2"><h2>Logo</h2></td></tr>
	<tr>
		<th scope="row"><label for="business_logo_url">Logo URL</label></th>
		<td>
			<input type="url" name="business_logo_url" id="business_logo_url" value="<?php echo esc_attr(get_option('business_logo_url', '')); ?>" class="large-text" placeholder="https://...">
			<p class="description">Full URL to your logo image (displayed in header and footer)</p>
		</td>
	</tr>

	<tr><td colspan="2"><h2>Header Top Bar</h2></td></tr>
	<tr>
		<th scope="row"><label for="header_top_mode">Top Bar Mode</label></th>
		<td>
			<select name="header_top_mode" id="header_top_mode">
				<option value="none" <?php selected($header_top_mode, 'none'); ?>>None (hidden)</option>
				<option value="tagline" <?php selected($header_top_mode, 'tagline'); ?>>Simple Tagline + Phone</option>
				<option value="items" <?php selected($header_top_mode, 'items'); ?>>Custom Items</option>
			</select>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="header_top_bg">Top Bar Background</label></th>
		<td><input type="text" name="header_top_bg" id="header_top_bg" value="<?php echo esc_attr(get_option('header_top_bg', '#f8f9fa')); ?>" class="regular-text" placeholder="#f8f9fa"></td>
	</tr>
	<tr>
		<th scope="row"><label for="header_top_text">Top Bar Text</label></th>
		<td><input type="text" name="header_top_text" id="header_top_text" value="<?php echo esc_attr(get_option('header_top_text', '#333333')); ?>" class="regular-text" placeholder="#333333"></td>
	</tr>

	<!-- Custom Header Items (shown when mode = items) -->
	<tr class="header-items-row">
		<th scope="row">Header Top Items</th>
		<td>
			<p class="description" style="margin-bottom:15px;">Configure up to 4 items for the top header bar. Types: badge (image), icon-box (icon + text), text, phone-button.</p>
			<?php for ($i = 0; $i < 4; $i++):
				$item = isset($header_top_items[$i]) ? $header_top_items[$i] : [];
			?>
			<fieldset style="border:1px solid #ccc; padding:15px; margin-bottom:15px; background:#fafafa;">
				<legend style="font-weight:bold;">Item <?php echo $i + 1; ?></legend>
				<table class="form-table" style="margin:0;">
					<tr>
						<th><label>Type</label></th>
						<td>
							<select name="header_top_items[<?php echo $i; ?>][type]">
								<option value="">-- None --</option>
								<option value="badge" <?php selected($item['type'] ?? '', 'badge'); ?>>Badge (Image)</option>
								<option value="icon-box" <?php selected($item['type'] ?? '', 'icon-box'); ?>>Icon Box</option>
								<option value="text" <?php selected($item['type'] ?? '', 'text'); ?>>Text Only</option>
								<option value="phone-button" <?php selected($item['type'] ?? '', 'phone-button'); ?>>Phone Button</option>
							</select>
						</td>
					</tr>
					<tr>
						<th><label>Icon (FA class)</label></th>
						<td><input type="text" name="header_top_items[<?php echo $i; ?>][icon]" value="<?php echo esc_attr($item['icon'] ?? ''); ?>" class="regular-text" placeholder="fa-star"></td>
					</tr>
					<tr>
						<th><label>Text</label></th>
						<td><input type="text" name="header_top_items[<?php echo $i; ?>][text]" value="<?php echo esc_attr($item['text'] ?? ''); ?>" class="regular-text"></td>
					</tr>
					<tr>
						<th><label>Subtext</label></th>
						<td><input type="text" name="header_top_items[<?php echo $i; ?>][subtext]" value="<?php echo esc_attr($item['subtext'] ?? ''); ?>" class="regular-text"></td>
					</tr>
					<tr>
						<th><label>Link URL</label></th>
						<td><input type="url" name="header_top_items[<?php echo $i; ?>][link]" value="<?php echo esc_attr($item['link'] ?? ''); ?>" class="regular-text"></td>
					</tr>
					<tr>
						<th><label>Image URL (badges)</label></th>
						<td><input type="url" name="header_top_items[<?php echo $i; ?>][image]" value="<?php echo esc_attr($item['image'] ?? ''); ?>" class="large-text"></td>
					</tr>
				</table>
			</fieldset>
			<?php endfor; ?>
		</td>
	</tr>

	<tr><td colspan="2"><h2>Header Navigation</h2></td></tr>
	<tr>
		<th scope="row"><label for="header_sticky">Sticky Header</label></th>
		<td>
			<label>
				<input type="checkbox" name="header_sticky" id="header_sticky" value="1" <?php checked(get_option('header_sticky'), '1'); ?>>
				Keep the header (logo + nav) pinned to the top while scrolling
			</label>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="lean_menu_location">Menu Location</label></th>
		<td>
			<select name="lean_menu_location" id="lean_menu_location">
				<option value="">-- Select Menu Location --</option>
				<?php
				$current_location = get_option('lean_menu_location', '');
				$locations = get_registered_nav_menus();
				foreach ($locations as $slug => $name) {
					printf(
						'<option value="%s" %s>%s (%s)</option>',
						esc_attr($slug),
						selected($current_location, $slug, false),
						esc_html($name),
						esc_html($slug)
					);
				}
				?>
			</select>
			<p class="description">Select which menu location to use for the main navigation</p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="header_main_bg">Header Background</label></th>
		<td><input type="text" name="header_main_bg" id="header_main_bg" value="<?php echo esc_attr(get_option('header_main_bg', '#ffffff')); ?>" class="regular-text" placeholder="#ffffff"></td>
	</tr>
	<tr>
		<th scope="row"><label for="header_nav_text">Nav Text Color</label></th>
		<td><input type="text" name="header_nav_text" id="header_nav_text" value="<?php echo esc_attr(get_option('header_nav_text', '#333333')); ?>" class="regular-text" placeholder="#333333"></td>
	</tr>
	<tr>
		<th scope="row"><label for="dropdown_bg">Dropdown Background</label></th>
		<td><input type="text" name="dropdown_bg" id="dropdown_bg" value="<?php echo esc_attr(get_option('dropdown_bg', '#ffffff')); ?>" class="regular-text" placeholder="#ffffff"></td>
	</tr>
	<tr>
		<th scope="row"><label for="dropdown_text">Dropdown Text Color</label></th>
		<td><input type="text" name="dropdown_text" id="dropdown_text" value="<?php echo esc_attr(get_option('dropdown_text', '#333333')); ?>" class="regular-text" placeholder="#333333"></td>
	</tr>

	<tr><td colspan="2"><h2>Brand Colors</h2></td></tr>
	<tr>
		<th scope="row"><label for="primary_color">Primary Color</label></th>
		<td>
			<input type="text" name="primary_color" id="primary_color" value="<?php echo esc_attr(get_option('primary_color')); ?>" class="regular-text" placeholder="#005395">
			<p class="description">Used for buttons, links, hero overlay (sets --brand CSS variable). Enter a hex value — leave blank for the theme default (<code>#005395</code>). Button text color (black or white) is auto-picked for WCAG contrast.</p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="secondary_color">Accent Color</label></th>
		<td>
			<input type="text" name="secondary_color" id="secondary_color" value="<?php echo esc_attr(get_option('secondary_color')); ?>" class="regular-text" placeholder="#daa520">
			<p class="description">Used for the .btn-cta CTA button and callouts (sets --accent CSS variable). Enter a hex value (e.g. <code>#ff7a59</code>) — leave blank for the theme default (<code>#daa520</code>). Button text color (black or white) is auto-picked for WCAG contrast.</p>
		</td>
	</tr>

	<tr><td colspan="2"><h2>Footer</h2></td></tr>
	<tr>
		<th scope="row"><label for="footer_bg">Footer Background</label></th>
		<td><input type="text" name="footer_bg" id="footer_bg" value="<?php echo esc_attr(get_option('footer_bg', '#212529')); ?>" class="regular-text" placeholder="#212529"></td>
	</tr>
	<tr>
		<th scope="row"><label for="footer_text">Footer Text Color</label></th>
		<td><input type="text" name="footer_text" id="footer_text" value="<?php echo esc_attr(get_option('footer_text', '#ffffff')); ?>" class="regular-text" placeholder="#ffffff"></td>
	</tr>

	<tr><td colspan="2"><h2>Footer Widgets</h2></td></tr>
	<tr>
		<td colspan="2">
			<p class="description">Configure up to 4 footer columns. Empty columns will be skipped. HTML and shortcodes are supported.</p>
		</td>
	</tr>
	<?php for ($i = 1; $i <= 4; $i++): ?>
	<tr>
		<th scope="row"><label for="footer_widget_<?php echo $i; ?>">Footer Widget <?php echo $i; ?></label></th>
		<td>
			<textarea name="footer_widget_<?php echo $i; ?>" id="footer_widget_<?php echo $i; ?>" rows="10" class="large-text code"><?php echo esc_textarea(get_option('footer_widget_' . $i, '')); ?></textarea>
			<p class="description">HTML and shortcodes allowed (e.g., [business_phone_link], [business_full_address])</p>
		</td>
	</tr>
	<?php endfor; ?>
	<?php
}

function lean_theme_analytics_fields() {
	?>
	<tr><td colspan="2"><h2>Google Tag Manager</h2><p class="description">Use GTM if you manage all tags through Tag Manager. Leave empty if using GA4 directly.</p></td></tr>
	<tr>
		<th scope="row"><label for="gtm_container_id">GTM Container ID</label></th>
		<td>
			<input type="text" name="gtm_container_id" id="gtm_container_id" value="<?php echo esc_attr(get_option('gtm_container_id', '')); ?>" class="regular-text" placeholder="GTM-XXXXXXX">
			<p class="description">Your Google Tag Manager Container ID (starts with GTM-). If set, GA4 below will be ignored.</p>
		</td>
	</tr>

	<tr><td colspan="2"><h2>Direct Analytics</h2><p class="description">Use these if NOT using Google Tag Manager.</p></td></tr>
	<tr>
		<th scope="row"><label for="ga4_measurement_id">GA4 Measurement ID</label></th>
		<td>
			<input type="text" name="ga4_measurement_id" id="ga4_measurement_id" value="<?php echo esc_attr(get_option('ga4_measurement_id', '')); ?>" class="regular-text" placeholder="G-XXXXXXXXXX">
			<p class="description">Your Google Analytics 4 Measurement ID (starts with G-). Ignored if GTM is set.</p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="clarity_project_id">MS Clarity Project ID</label></th>
		<td>
			<input type="text" name="clarity_project_id" id="clarity_project_id" value="<?php echo esc_attr(get_option('clarity_project_id', '')); ?>" class="regular-text">
			<p class="description">Your Microsoft Clarity Project ID</p>
		</td>
	</tr>
	<?php
}

function lean_theme_form_fields() {
	?>
	<tr>
		<th scope="row"><label for="form_recipient_email">Recipient Email(s)</label></th>
		<td>
			<input type="text" name="form_recipient_email" id="form_recipient_email" value="<?php echo esc_attr(get_option('form_recipient_email', '')); ?>" class="regular-text">
			<p class="description">Comma-separated for multiple recipients</p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="form_from_email">"From" Email</label></th>
		<td>
			<input type="email" name="form_from_email" id="form_from_email" value="<?php echo esc_attr(get_option('form_from_email', '')); ?>" class="regular-text">
			<p class="description">The "From" address for form notification emails</p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="form_success_message">Success Message</label></th>
		<td><input type="text" name="form_success_message" id="form_success_message" value="<?php echo esc_attr(get_option('form_success_message', "Message sent. We'll contact you within 24 hours.")); ?>" class="large-text"></td>
	</tr>
	<tr>
		<th scope="row"><label for="form_error_message">Error Message</label></th>
		<td><input type="text" name="form_error_message" id="form_error_message" value="<?php echo esc_attr(get_option('form_error_message', 'Error sending message. Please call us directly.')); ?>" class="large-text"></td>
	</tr>
	<tr>
		<th scope="row">Confirmation Email</th>
		<td>
			<label>
				<input type="checkbox" name="form_send_confirmation" value="1" <?php checked(get_option('form_send_confirmation'), '1'); ?>>
				Send confirmation email to the person who submitted the form
			</label>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="lean_webmcp_origin_trial_token">WebMCP Origin Trial Token</label></th>
		<td>
			<input type="text" name="lean_webmcp_origin_trial_token" id="lean_webmcp_origin_trial_token" value="<?php echo esc_attr(get_option('lean_webmcp_origin_trial_token', '')); ?>" class="large-text">
			<p class="description">
				Optional, off by default. Paste this site's per-origin <a href="https://developer.chrome.com/docs/ai/webmcp/declarative-api" target="_blank" rel="noopener">declarative WebMCP</a> Origin Trial token to make the Lean contact form an agent-callable tool (in-browser AI agents can then fill it; the visitor still submits). <strong>Until a token is saved here, no WebMCP attributes are emitted at all</strong> &mdash; this is an explicit opt-in because it turns a public lead form into an automatable tool. Register at the <a href="https://developer.chrome.com/origintrials/" target="_blank" rel="noopener">Chrome Origin Trials</a> console (token is tied to this exact domain). Agent-readiness only &mdash; not a performance or SEO signal, no PageSpeed impact.
			</p>
		</td>
	</tr>
	<?php
}

function lean_theme_booking_fields() {
	?>
	<tr>
		<th scope="row"><label for="booking_code">Booking Code</label></th>
		<td>
			<textarea name="booking_code" id="booking_code" rows="6" class="large-text code"><?php echo esc_textarea(get_option('booking_code', '')); ?></textarea>
			<p class="description">Enter a booking URL (e.g., <code>https://booking.example.com</code>) or custom HTML such as a 3rd-party booking button. Use <code>{text}</code> as a placeholder for dynamic button text via the shortcode's <code>text</code> attribute. Used by the <code>[business_booking]</code> shortcode.</p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="booking_widget_script">Booking Widget Script</label></th>
		<td>
			<textarea name="booking_widget_script" id="booking_widget_script" rows="4" class="large-text code"><?php echo esc_textarea(get_option('booking_widget_script', '')); ?></textarea>
			<p class="description">Script tag for 3rd-party booking widgets (e.g., HouseCall Pro, Calendly). Automatically loaded in the footer on every page.</p>
		</td>
	</tr>
	<?php
}

function lean_theme_hours_fields() {
	$hours = get_option('business_hours', []);
	$days = [
		'mon' => 'Monday',
		'tue' => 'Tuesday',
		'wed' => 'Wednesday',
		'thu' => 'Thursday',
		'fri' => 'Friday',
		'sat' => 'Saturday',
		'sun' => 'Sunday',
	];
	?>
	<tr>
		<td colspan="2" style="padding-top:0;">
			<p class="description" style="font-size:13px;">
				Set business hours for each day. Leave a day blank to mark it as closed.
				Use the <strong>second set</strong> only if you close mid-day (e.g., for a lunch break).
				Tick <strong>24 hrs</strong> to mark a day as open around the clock — this overrides any times set for that day.
				Output via the <code>[business_hours]</code> shortcode (already placed in Footer Widget 4 by default).
				Timezone follows your <a href="<?php echo esc_url(admin_url('options-general.php')); ?>">WordPress site timezone</a>.
			</p>
		</td>
	</tr>
	<tr>
		<th scope="row">Hours of Operation</th>
		<td>
			<table class="widefat striped lean-hours-admin" style="max-width:840px;">
				<thead>
					<tr>
						<th style="width:110px;">Day</th>
						<th style="width:80px;">Closed</th>
						<th style="width:80px;">24 hrs</th>
						<th>Set 1 (open – close)</th>
						<th>Set 2 (optional)</th>
					</tr>
				</thead>
				<tbody>
				<?php foreach ($days as $key => $label):
					$day = isset($hours[$key]) ? $hours[$key] : ['closed' => false, 'is_24h' => false, 'sets' => []];
					$closed = !empty($day['closed']);
					$is_24h = !empty($day['is_24h']);
					$set1_open  = isset($day['sets'][0]['open'])  ? $day['sets'][0]['open']  : '';
					$set1_close = isset($day['sets'][0]['close']) ? $day['sets'][0]['close'] : '';
					$set2_open  = isset($day['sets'][1]['open'])  ? $day['sets'][1]['open']  : '';
					$set2_close = isset($day['sets'][1]['close']) ? $day['sets'][1]['close'] : '';
				?>
					<tr data-day-row="<?php echo esc_attr($key); ?>">
						<td><strong><?php echo esc_html($label); ?></strong></td>
						<td>
							<input type="checkbox" class="lean-hours-closed" name="business_hours[<?php echo $key; ?>][closed]" value="1" <?php checked($closed); ?>>
						</td>
						<td>
							<input type="checkbox" class="lean-hours-24h" name="business_hours[<?php echo $key; ?>][is_24h]" value="1" <?php checked($is_24h); ?>>
						</td>
						<td>
							<input type="time" name="business_hours[<?php echo $key; ?>][set1_open]"  value="<?php echo esc_attr($set1_open); ?>">
							&ndash;
							<input type="time" name="business_hours[<?php echo $key; ?>][set1_close]" value="<?php echo esc_attr($set1_close); ?>">
						</td>
						<td>
							<input type="time" name="business_hours[<?php echo $key; ?>][set2_open]"  value="<?php echo esc_attr($set2_open); ?>">
							&ndash;
							<input type="time" name="business_hours[<?php echo $key; ?>][set2_close]" value="<?php echo esc_attr($set2_close); ?>">
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<script>
			(function(){
				function syncRow(row) {
					var closed = row.querySelector('.lean-hours-closed');
					var is24   = row.querySelector('.lean-hours-24h');
					var times  = row.querySelectorAll('input[type="time"]');
					var disable = (closed && closed.checked) || (is24 && is24.checked);
					times.forEach(function(el){ el.disabled = disable; el.style.opacity = disable ? 0.45 : 1; });
					if (is24 && is24.checked && closed) closed.disabled = true; else if (closed) closed.disabled = false;
					if (closed && closed.checked && is24) is24.disabled = true; else if (is24) is24.disabled = false;
				}
				var rows = document.querySelectorAll('.lean-hours-admin tr[data-day-row]');
				rows.forEach(function(row){ syncRow(row); row.addEventListener('change', function(){ syncRow(row); }); });
			})();
			</script>
		</td>
	</tr>
	<?php
}

function lean_theme_shortcodes_reference() {
	?>
	<tr>
		<td colspan="2">
			<h2>Available Shortcodes</h2>
			<p>Use these shortcodes in your pages and posts:</p>

			<h3>Business Information</h3>
			<table class="widefat striped" style="max-width:600px;">
				<thead><tr><th>Shortcode</th><th>Output</th></tr></thead>
				<tbody>
					<tr><td><code>[business_name]</code></td><td><?php echo esc_html(get_option('business_name', '(not set)')); ?></td></tr>
					<tr><td><code>[business_phone]</code></td><td><?php echo esc_html(get_option('business_phone', '(not set)')); ?></td></tr>
					<tr><td><code>[business_phone_link]</code></td><td>Clickable phone link</td></tr>
					<tr><td><code>[business_phone_url]</code></td><td>tel: URL only</td></tr>
					<tr><td><code>[business_phone_button class="btn btn-primary"]</code></td><td>Phone link with custom class</td></tr>
					<tr><td><code>[business_address]</code></td><td><?php echo esc_html(get_option('business_address', '(not set)')); ?></td></tr>
					<tr><td><code>[business_city]</code></td><td><?php echo esc_html(get_option('business_city', '(not set)')); ?></td></tr>
					<tr><td><code>[business_state]</code></td><td><?php echo esc_html(get_option('business_state', '(not set)')); ?></td></tr>
					<tr><td><code>[business_zip]</code></td><td><?php echo esc_html(get_option('business_zip', '(not set)')); ?></td></tr>
					<tr><td><code>[business_full_address]</code></td><td>Full formatted address</td></tr>
					<tr><td><code>[business_url]</code></td><td><?php echo esc_html(get_option('business_url', home_url())); ?></td></tr>
					<tr><td><code>[business_logo_url]</code></td><td>Logo image URL</td></tr>
					<tr><td><code>[business_booking]</code></td><td>Booking button (default)</td></tr>
					<tr><td><code>[business_booking type="link" text="Book"]</code></td><td>Booking as plain link</td></tr>
					<tr><td><code>[business_booking type="custom"]</code></td><td>Custom booking widget HTML</td></tr>
				</tbody>
			</table>

			<h3 style="margin-top:20px;">Google</h3>
			<table class="widefat striped" style="max-width:600px;">
				<thead><tr><th>Shortcode</th><th>Description</th></tr></thead>
				<tbody>
					<tr><td><code>[google_maps_cid]</code></td><td>Google Maps CID</td></tr>
					<tr><td><code>[google_kgid]</code></td><td>Knowledge Graph ID</td></tr>
					<tr><td><code>[google_gmb_image_url]</code></td><td>GMB Image URL</td></tr>
					<tr><td><code>[map_embed]</code></td><td>Google Map with GMB overlay</td></tr>
				</tbody>
			</table>

			<h3 style="margin-top:20px;">Content</h3>
			<table class="widefat striped" style="max-width:600px;">
				<thead><tr><th>Shortcode</th><th>Description</th></tr></thead>
				<tbody>
					<tr><td><code>[lean_form]</code></td><td>Contact form</td></tr>
					<tr><td><code>[testimonials num_reviews="6"]</code></td><td>Display the newest testimonials (all categories)</td></tr>
					<tr><td><code>[testimonials category="maintenance"]</code></td><td>Only the <em>maintenance</em> testimonial category (slug); comma-separate for several, e.g. <code>category="hvac,plumbing"</code></td></tr>
					<tr><td><code>[testimonials category="maintenance" num_reviews="6"]</code></td><td>If the category has fewer than <code>num_reviews</code>, top up the rest at random from the <em>generic</em> category</td></tr>
					<tr><td><code>[testimonials category="maintenance" fallback="reviews"]</code></td><td>Use a custom top-up category instead of <em>generic</em>; <code>fallback=""</code> disables top-up</td></tr>
					<tr><td><code>[latest_blog_post]</code></td><td>Link to latest post</td></tr>
				</tbody>
			</table>
		</td>
	</tr>
	<?php
}

// ──────────────────────────────────────────────────────────────────────────────
// DEFAULT FOOTER WIDGETS
// ──────────────────────────────────────────────────────────────────────────────

/**
 * Populate default footer widgets on theme activation
 */
function lean_theme_set_default_footer_widgets() {
	// Only set if footer_widget_1 is empty (first activation)
	if (get_option('footer_widget_1') === false) {
		// Widget 1: Logo & Contact Info
		$widget_1 = '<?php $logo_url = get_option("business_logo_url"); $business_name = get_option("business_name", get_bloginfo("name")); ?>
<?php if ($logo_url): ?>
<img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr($business_name); ?>" width="300" height="169" loading="lazy" />
<?php endif; ?>
<div class="mt-3">
	<div class="footer-business-name" style="font-size: 1.5rem; margin-bottom: 10px;">
		<strong><?php echo esc_html($business_name); ?></strong>
	</div>
	<p style="font-size: 1.5rem; margin-bottom: 5px;"><strong>Address:</strong></p>
	<div class="footer-address" style="margin-bottom: 15px;">
		[business_full_address]
	</div>
	<div class="phone-number">
		<p style="font-size: 1.5rem; margin-bottom: 5px;"><strong>Phone:</strong></p>
		[business_phone_link]
	</div>
</div>';

		// Widget 2: Google Map
		$widget_2 = '<?php
$google_maps_cid = get_option("google_maps_cid", "");
$google_maps_embed_url = get_option("google_maps_embed_url", "");
$business_name = get_option("business_name", get_bloginfo("name"));
$map_src = "";
if ($google_maps_embed_url) {
	$map_src = $google_maps_embed_url;
} elseif ($google_maps_cid) {
	$map_src = "https://www.google.com/maps?cid=" . esc_attr($google_maps_cid) . "&output=embed";
}
if ($map_src):
?>
<div class="map-container">
	<iframe src="<?php echo esc_url($map_src); ?>" width="100%" height="350" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" title="Map to <?php echo esc_attr($business_name); ?>"></iframe>
</div>
<?php endif; ?>';

		// Widget 3: Empty (for user customization)
		$widget_3 = '';

		// Widget 4: Business hours + open/closed status (configured in Hours settings tab)
		$widget_4 = '[business_hours]';

		update_option('footer_widget_1', $widget_1);
		update_option('footer_widget_2', $widget_2);
		update_option('footer_widget_3', $widget_3);
		update_option('footer_widget_4', $widget_4);
	}
}
add_action('after_switch_theme', 'lean_theme_set_default_footer_widgets');

// ──────────────────────────────────────────────────────────────────────────────
// SAVE SETTINGS
// ──────────────────────────────────────────────────────────────────────────────

function lean_theme_save_settings() {
	// Text fields
	$text_fields = array(
		'business_name', 'header_tagline', 'business_phone', 'business_address',
		'business_city', 'business_state', 'business_zip', 'business_county',
		'google_maps_cid', 'google_kgid', 'gtm_container_id', 'ga4_measurement_id', 'clarity_project_id',
		'primary_color', 'secondary_color',
		'lean_default_language',
		'lean_menu_location',
		'header_top_mode', 'header_top_bg', 'header_top_text',
		'header_main_bg', 'header_nav_text', 'dropdown_bg', 'dropdown_text',
		'footer_bg', 'footer_text',
		'form_success_message', 'form_error_message',
		'lean_webmcp_origin_trial_token'
	);

	foreach ($text_fields as $field) {
		if (isset($_POST[$field])) {
			update_option($field, sanitize_text_field($_POST[$field]));
		}
	}

	// URL fields
	$url_fields = array('business_url', 'business_logo_url', 'google_gmb_image_url', 'google_maps_embed_url');
	foreach ($url_fields as $field) {
		if (isset($_POST[$field])) {
			update_option($field, esc_url_raw($_POST[$field]));
		}
	}

	// Email fields
	if (isset($_POST['form_recipient_email'])) {
		update_option('form_recipient_email', sanitize_text_field($_POST['form_recipient_email']));
	}
	if (isset($_POST['form_from_email'])) {
		update_option('form_from_email', sanitize_email($_POST['form_from_email']));
	}
	if (isset($_POST['business_email'])) {
		update_option('business_email', sanitize_email($_POST['business_email']));
	}

	// Checkboxes — only update when the form for the relevant tab was submitted
	$active_tab = isset($_POST['active_tab']) ? sanitize_text_field($_POST['active_tab']) : '';
	if ($active_tab === 'forms') {
		update_option('form_send_confirmation', isset($_POST['form_send_confirmation']) ? '1' : '');
	}
	if ($active_tab === 'appearance') {
		update_option('header_sticky', isset($_POST['header_sticky']) ? '1' : '');
	}

	// Header top items (array)
	if (isset($_POST['header_top_items']) && is_array($_POST['header_top_items'])) {
		$sanitized_items = [];
		foreach ($_POST['header_top_items'] as $item) {
			$sanitized_items[] = [
				'type'    => sanitize_text_field($item['type'] ?? ''),
				'icon'    => sanitize_text_field($item['icon'] ?? ''),
				'text'    => sanitize_text_field($item['text'] ?? ''),
				'subtext' => sanitize_text_field($item['subtext'] ?? ''),
				'link'    => esc_url_raw($item['link'] ?? ''),
				'image'   => esc_url_raw($item['image'] ?? ''),
			];
		}
		update_option('header_top_items', $sanitized_items);
	}

	// Footer widgets (allow HTML/PHP - admin only, page gated by manage_options)
	for ($i = 1; $i <= 4; $i++) {
		if (isset($_POST['footer_widget_' . $i])) {
			update_option('footer_widget_' . $i, wp_unslash($_POST['footer_widget_' . $i]));
		}
	}

	// Booking fields (allow HTML/script - admin only, page gated by manage_options)
	if (isset($_POST['booking_code'])) {
		update_option('booking_code', wp_unslash($_POST['booking_code']));
	}
	if (isset($_POST['booking_widget_script'])) {
		update_option('booking_widget_script', wp_unslash($_POST['booking_widget_script']));
	}

	// Business hours (array — per-day closed flag + up to 2 sets of open/close times)
	if (isset($_POST['business_hours']) && is_array($_POST['business_hours'])) {
		$valid_days = ['mon','tue','wed','thu','fri','sat','sun'];
		$time_re = '/^([01][0-9]|2[0-3]):[0-5][0-9]$/';
		$clean = [];
		foreach ($valid_days as $key) {
			$row = $_POST['business_hours'][$key] ?? [];
			$is_24h = !empty($row['is_24h']);
			// 24 hrs overrides closed (and times); never both at once
			$closed = !$is_24h && !empty($row['closed']);
			$sets = [];
			foreach ([1, 2] as $n) {
				$open  = isset($row["set{$n}_open"])  ? trim($row["set{$n}_open"])  : '';
				$close = isset($row["set{$n}_close"]) ? trim($row["set{$n}_close"]) : '';
				if ($open !== '' && $close !== '' && preg_match($time_re, $open) && preg_match($time_re, $close)) {
					$sets[] = ['open' => $open, 'close' => $close];
				}
			}
			$clean[$key] = ['closed' => $closed, 'is_24h' => $is_24h, 'sets' => $sets];
		}
		update_option('business_hours', $clean);
	}
}

// ──────────────────────────────────────────────────────────────────────────────
// INJECT CUSTOM COLORS AS CSS VARIABLES
// ──────────────────────────────────────────────────────────────────────────────

// Theme defaults for brand vars. Used when the admin hasn't filled in a custom
// color. Kept in PHP (not in lean-pages.css) so there is a single :root source
// of truth — avoids a brief flash of the default color on first paint.
define('LEAN_DEFAULT_PRIMARY_COLOR', '#005395');
define('LEAN_DEFAULT_ACCENT_COLOR', '#daa520');

function lean_theme_inject_custom_colors() {
	$primary_color = get_option('primary_color');
	if (!$primary_color) {
		$primary_color = LEAN_DEFAULT_PRIMARY_COLOR;
	}

	$secondary_color = get_option('secondary_color');
	if (!$secondary_color) {
		$secondary_color = LEAN_DEFAULT_ACCENT_COLOR;
	}

	echo '<style>:root{';

	$rgb = lean_hex_to_rgb($primary_color);
	echo '--brand:' . esc_attr($primary_color) . ';';
	echo '--brand-dark:' . esc_attr(lean_adjust_brightness($primary_color, -15)) . ';';
	echo '--brand-darker:' . esc_attr(lean_adjust_brightness($primary_color, -25)) . ';';
	if ($rgb) {
		echo '--brand-rgb:' . esc_attr($rgb['r'] . ',' . $rgb['g'] . ',' . $rgb['b']) . ';';
	}
	echo '--brand-fg:' . esc_attr(lean_contrast_color($primary_color)) . ';';

	echo '--accent:' . esc_attr($secondary_color) . ';';
	echo '--accent-fg:' . esc_attr(lean_contrast_color($secondary_color)) . ';';

	echo '}</style>';
}
add_action('wp_head', 'lean_theme_inject_custom_colors');
// Lean templates bypass wp_head(); the lean_head action fires AFTER lean-pages.css
// loads, which is required so the injected :root overrides win the cascade.
add_action('lean_head', 'lean_theme_inject_custom_colors');

/**
 * Convert hex color to RGB array
 */
function lean_hex_to_rgb($hex) {
	$hex = ltrim($hex, '#');
	if (strlen($hex) === 3) {
		$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
	}
	if (strlen($hex) !== 6) {
		return false;
	}
	return [
		'r' => hexdec(substr($hex, 0, 2)),
		'g' => hexdec(substr($hex, 2, 2)),
		'b' => hexdec(substr($hex, 4, 2)),
	];
}

/**
 * Pick a foreground color (white or dark) that maximizes WCAG contrast
 * against the given background. Returns whichever of #fff or #212529 has
 * the higher contrast ratio per the WCAG 2.x relative-luminance formula.
 *
 * If $hex can't be parsed (e.g. a CSS keyword), returns #212529 as a safe
 * default that passes against most lightish accent colors.
 *
 * @param string $hex Background color (hex, with or without leading #)
 * @return string '#fff' or '#212529'
 */
function lean_contrast_color($hex) {
	$rgb = lean_hex_to_rgb($hex);
	if (!$rgb) {
		return '#212529';
	}

	// Convert sRGB channel to linear-light, then compute relative luminance.
	$linear = function ($c) {
		$c = $c / 255;
		return $c <= 0.03928 ? $c / 12.92 : pow(($c + 0.055) / 1.055, 2.4);
	};
	$L = 0.2126 * $linear($rgb['r']) + 0.7152 * $linear($rgb['g']) + 0.0722 * $linear($rgb['b']);

	// Contrast ratios against pure white (L=1) and against #212529 (L≈0.0125).
	$contrast_white = (1.0 + 0.05) / ($L + 0.05);
	$contrast_dark  = ($L + 0.05) / (0.0125 + 0.05);

	return $contrast_white >= $contrast_dark ? '#fff' : '#212529';
}

/**
 * Adjust hex color brightness
 * @param string $hex Hex color
 * @param int $percent Positive = lighter, Negative = darker
 */
function lean_adjust_brightness($hex, $percent) {
	$hex = ltrim($hex, '#');
	if (strlen($hex) === 3) {
		$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
	}

	$rgb = [
		hexdec(substr($hex, 0, 2)),
		hexdec(substr($hex, 2, 2)),
		hexdec(substr($hex, 4, 2)),
	];

	foreach ($rgb as &$color) {
		$color = max(0, min(255, $color + ($color * $percent / 100)));
		$color = round($color);
	}

	return sprintf('#%02x%02x%02x', $rgb[0], $rgb[1], $rgb[2]);
}

// ──────────────────────────────────────────────────────────────────────────────
// SHORTCODES
// ──────────────────────────────────────────────────────────────────────────────
// Business shortcodes have been moved to: inc/shortcodes/business-info.php
// Load via: inc/shortcodes.php
